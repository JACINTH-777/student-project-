import { useState, useMemo } from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/app/components/ui/card';
import { Badge } from '@/app/components/ui/badge';
import { Button } from '@/app/components/ui/button';
import { BookOpen, Calendar, Users, ExternalLink, BookmarkPlus, Award } from 'lucide-react';

interface Publication {
  id: string;
  title: string;
  authors: string[];
  abstract: string;
  category: string;
  year: number;
  journal: string;
  citations: number;
  tags: string[];
  impactFactor?: number;
  url?: string;
}

const publicationsData: Publication[] = [
  {
    id: '1',
    title: 'Deep Learning Approaches for Image Recognition in Mobile Applications',
    authors: ['Sarah Johnson', 'Michael Chen', 'Dr. Emily Rodriguez'],
    abstract: 'This paper explores novel deep learning architectures optimized for mobile devices, achieving 95% accuracy in real-time image classification while maintaining low power consumption.',
    category: 'Computer Science',
    year: 2025,
    journal: 'IEEE Transactions on Mobile Computing',
    citations: 87,
    tags: ['Deep Learning', 'Mobile Computing', 'Computer Vision'],
    impactFactor: 7.2,
    url: 'https://example.com/paper1'
  },
  {
    id: '2',
    title: 'Renewable Energy Integration in Smart Grid Systems',
    authors: ['Dr. James Wilson', 'Anna Martinez'],
    abstract: 'An analysis of optimization algorithms for integrating solar and wind energy into existing power grids, with a focus on reducing energy waste and improving distribution efficiency.',
    category: 'Electrical Engineering',
    year: 2024,
    journal: 'Energy and Power Engineering',
    citations: 142,
    tags: ['Smart Grid', 'Renewable Energy', 'Optimization'],
    impactFactor: 5.8,
    url: 'https://example.com/paper2'
  },
  {
    id: '3',
    title: 'Natural Language Processing for Educational Content Generation',
    authors: ['Dr. Lisa Park', 'Robert Kumar', 'Jennifer Lee'],
    abstract: 'Presents a transformer-based model that automatically generates personalized educational content and quizzes based on student learning patterns and knowledge gaps.',
    category: 'Computer Science',
    year: 2025,
    journal: 'Journal of Artificial Intelligence in Education',
    citations: 63,
    tags: ['NLP', 'Education Technology', 'AI'],
    impactFactor: 6.4,
    url: 'https://example.com/paper3'
  },
  {
    id: '4',
    title: 'IoT Security Protocols for Smart Home Networks',
    authors: ['Dr. David Thompson', 'Maria Garcia'],
    abstract: 'Proposes a lightweight encryption protocol designed specifically for IoT devices with limited computational resources, improving security without compromising performance.',
    category: 'Computer Science',
    year: 2024,
    journal: 'Computer Networks',
    citations: 198,
    tags: ['IoT', 'Security', 'Networking'],
    impactFactor: 8.1,
    url: 'https://example.com/paper4'
  },
  {
    id: '5',
    title: 'Autonomous Navigation Systems for Collaborative Robots',
    authors: ['Dr. Kevin Zhang', 'Sophia Adams', 'Marcus Brown'],
    abstract: 'Develops a decentralized control algorithm enabling multiple robots to navigate shared spaces safely and efficiently using computer vision and sensor fusion.',
    category: 'Robotics',
    year: 2025,
    journal: 'Robotics and Autonomous Systems',
    citations: 45,
    tags: ['Autonomous Systems', 'Computer Vision', 'Multi-Robot Systems'],
    impactFactor: 7.5,
    url: 'https://example.com/paper5'
  },
  {
    id: '6',
    title: 'Machine Learning for Predictive Maintenance in Manufacturing',
    authors: ['Dr. Rachel Cooper', 'Tom Anderson'],
    abstract: 'Introduces a hybrid ML model combining sensor data and historical maintenance records to predict equipment failures with 92% accuracy, reducing downtime in industrial settings.',
    category: 'Computer Science',
    year: 2024,
    journal: 'Industrial Engineering Applications',
    citations: 176,
    tags: ['Machine Learning', 'Predictive Analytics', 'IoT'],
    impactFactor: 6.9,
    url: 'https://example.com/paper6'
  },
  {
    id: '7',
    title: 'Wireless Power Transfer Systems for Electric Vehicles',
    authors: ['Dr. Christopher Lee', 'Amanda White', 'Dr. Hassan Ahmed'],
    abstract: 'Presents an inductive charging system achieving 94% efficiency for dynamic wireless charging of electric vehicles during motion, addressing range anxiety concerns.',
    category: 'Electrical Engineering',
    year: 2025,
    journal: 'IEEE Transactions on Power Electronics',
    citations: 91,
    tags: ['Wireless Power', 'Electric Vehicles', 'Power Electronics'],
    impactFactor: 8.7,
    url: 'https://example.com/paper7'
  },
  {
    id: '8',
    title: 'Blockchain Applications in Supply Chain Management',
    authors: ['Dr. Priya Patel', 'John Miller'],
    abstract: 'Explores the use of blockchain technology to improve transparency and traceability in global supply chains, with case studies from pharmaceutical and food industries.',
    category: 'Computer Science',
    year: 2024,
    journal: 'Supply Chain Technology Review',
    citations: 234,
    tags: ['Blockchain', 'Supply Chain', 'Distributed Systems'],
    impactFactor: 7.8,
    url: 'https://example.com/paper8'
  },
  {
    id: '9',
    title: 'Edge Computing for Real-Time Video Analytics',
    authors: ['Dr. William Scott', 'Olivia Turner', 'Alex Kim'],
    abstract: 'Demonstrates how edge computing reduces latency in video surveillance systems by processing data locally, achieving real-time object detection and tracking.',
    category: 'Computer Science',
    year: 2025,
    journal: 'ACM Transactions on Multimedia Computing',
    citations: 58,
    tags: ['Edge Computing', 'Video Analytics', 'Computer Vision'],
    impactFactor: 6.2,
    url: 'https://example.com/paper9'
  },
  {
    id: '10',
    title: 'Neuromorphic Computing for Energy-Efficient AI',
    authors: ['Dr. Elena Volkov', 'Carlos Mendez'],
    abstract: 'Investigates brain-inspired computing architectures that reduce energy consumption in AI workloads by up to 1000x compared to traditional GPU-based systems.',
    category: 'Computer Science',
    year: 2024,
    journal: 'Nature Electronics',
    citations: 312,
    tags: ['Neuromorphic Computing', 'AI', 'Hardware'],
    impactFactor: 9.3,
    url: 'https://example.com/paper10'
  }
];

const categories = ['All', 'Computer Science', 'Electrical Engineering', 'Robotics'];
const years = ['All', '2025', '2024', '2023'];

export function Publications({ searchQuery }: { searchQuery: string }) {
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [selectedYear, setSelectedYear] = useState('All');

  const filteredPublications = useMemo(() => {
    return publicationsData.filter((publication) => {
      const matchesSearch = searchQuery === '' || 
        publication.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        publication.abstract.toLowerCase().includes(searchQuery.toLowerCase()) ||
        publication.authors.some(author => author.toLowerCase().includes(searchQuery.toLowerCase())) ||
        publication.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()));
      
      const matchesCategory = selectedCategory === 'All' || publication.category === selectedCategory;
      const matchesYear = selectedYear === 'All' || publication.year.toString() === selectedYear;

      return matchesSearch && matchesCategory && matchesYear;
    });
  }, [searchQuery, selectedCategory, selectedYear]);

  return (
    <div>
      {/* Filters */}
      <div className="mb-6 flex flex-wrap gap-4">
        <div>
          <label className="text-sm font-medium text-gray-700 mb-2 block">Category</label>
          <div className="flex flex-wrap gap-2">
            {categories.map((category) => (
              <Button
                key={category}
                variant={selectedCategory === category ? 'default' : 'outline'}
                size="sm"
                onClick={() => setSelectedCategory(category)}
              >
                {category}
              </Button>
            ))}
          </div>
        </div>

        <div>
          <label className="text-sm font-medium text-gray-700 mb-2 block">Year</label>
          <div className="flex flex-wrap gap-2">
            {years.map((year) => (
              <Button
                key={year}
                variant={selectedYear === year ? 'default' : 'outline'}
                size="sm"
                onClick={() => setSelectedYear(year)}
              >
                {year}
              </Button>
            ))}
          </div>
        </div>
      </div>

      {/* Results Count */}
      <div className="mb-4 text-sm text-gray-600">
        Found {filteredPublications.length} publication{filteredPublications.length !== 1 ? 's' : ''}
      </div>

      {/* Publication Cards */}
      <div className="space-y-6">
        {filteredPublications.map((publication) => (
          <Card key={publication.id} className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <div className="flex items-start justify-between mb-2 flex-wrap gap-2">
                <div className="flex flex-wrap gap-2">
                  <Badge variant="secondary">{publication.category}</Badge>
                  {publication.impactFactor && publication.impactFactor > 7 && (
                    <Badge variant="default" className="bg-yellow-500">
                      <Award className="h-3 w-3 mr-1" />
                      High Impact
                    </Badge>
                  )}
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <Calendar className="h-4 w-4" />
                  <span>{publication.year}</span>
                </div>
              </div>
              <CardTitle className="text-xl">{publication.title}</CardTitle>
              <CardDescription className="flex items-center gap-2 text-sm">
                <Users className="h-4 w-4" />
                {publication.authors.join(', ')}
              </CardDescription>
            </CardHeader>

            <CardContent>
              <div className="space-y-4">
                <p className="text-gray-700 text-sm leading-relaxed">{publication.abstract}</p>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-3 border-t">
                  <div className="flex items-center gap-2">
                    <BookOpen className="h-4 w-4 text-gray-500" />
                    <div>
                      <span className="text-xs text-gray-500">Journal:</span>
                      <p className="text-sm font-medium">{publication.journal}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <Award className="h-4 w-4 text-gray-500" />
                    <div>
                      <span className="text-xs text-gray-500">Citations:</span>
                      <p className="text-sm font-medium">{publication.citations}</p>
                    </div>
                  </div>

                  {publication.impactFactor && (
                    <div className="flex items-center gap-2">
                      <div className="h-4 w-4 flex items-center justify-center">
                        <span className="text-xs font-bold text-gray-500">IF</span>
                      </div>
                      <div>
                        <span className="text-xs text-gray-500">Impact Factor:</span>
                        <p className="text-sm font-medium">{publication.impactFactor}</p>
                      </div>
                    </div>
                  )}
                </div>

                <div>
                  <div className="text-sm font-medium mb-2">Research Areas:</div>
                  <div className="flex flex-wrap gap-1">
                    {publication.tags.map((tag, idx) => (
                      <Badge key={idx} variant="outline" className="text-xs bg-green-50">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                </div>
              </div>
            </CardContent>

            <CardFooter className="flex gap-2">
              <Button className="flex-1" variant="default">
                <ExternalLink className="h-4 w-4 mr-2" />
                Read Paper
              </Button>
              <Button variant="outline">
                <BookmarkPlus className="h-4 w-4 mr-2" />
                Save
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>

      {filteredPublications.length === 0 && (
        <div className="text-center py-12">
          <p className="text-gray-500 text-lg">No publications found matching your criteria.</p>
          <p className="text-gray-400 mt-2">Try adjusting your filters or search query.</p>
        </div>
      )}
    </div>
  );
}
