import { useState, useMemo } from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/app/components/ui/card';
import { Badge } from '@/app/components/ui/badge';
import { Button } from '@/app/components/ui/button';
import { BookmarkPlus, Code2, GraduationCap, Clock, TrendingUp } from 'lucide-react';

interface Project {
  id: string;
  title: string;
  description: string;
  category: string;
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced';
  duration: string;
  tags: string[];
  skills: string[];
}

const projectsData: Project[] = [
  {
    id: '1',
    title: 'Smart Campus Navigation System',
    description: 'Build a mobile app that helps students navigate campus using AR technology, showing real-time directions to classrooms, labs, and facilities.',
    category: 'Computer Science',
    difficulty: 'Advanced',
    duration: '3-4 months',
    tags: ['Mobile Development', 'AR', 'GPS'],
    skills: ['React Native', 'ARKit', 'Google Maps API']
  },
  {
    id: '2',
    title: 'Automated Plant Watering System',
    description: 'Create an IoT-based system that monitors soil moisture and automatically waters plants while sending notifications to your phone.',
    category: 'Electrical Engineering',
    difficulty: 'Intermediate',
    duration: '2-3 months',
    tags: ['IoT', 'Arduino', 'Sensors'],
    skills: ['C++', 'Circuit Design', 'Mobile App Development']
  },
  {
    id: '3',
    title: 'AI-Powered Study Buddy',
    description: 'Develop a chatbot that helps students with homework, creates personalized study plans, and tracks learning progress using machine learning.',
    category: 'Computer Science',
    difficulty: 'Advanced',
    duration: '4-5 months',
    tags: ['AI', 'NLP', 'Machine Learning'],
    skills: ['Python', 'TensorFlow', 'Natural Language Processing']
  },
  {
    id: '4',
    title: 'Solar-Powered Phone Charger',
    description: 'Design and build a portable solar charger with battery storage, optimized for efficiency and portability.',
    category: 'Electrical Engineering',
    difficulty: 'Beginner',
    duration: '1-2 months',
    tags: ['Renewable Energy', 'Hardware'],
    skills: ['Circuit Design', 'PCB Design', 'Power Electronics']
  },
  {
    id: '5',
    title: 'College Event Management Platform',
    description: 'Build a comprehensive web platform for managing college events, including registration, ticketing, and attendee tracking.',
    category: 'Computer Science',
    difficulty: 'Intermediate',
    duration: '2-3 months',
    tags: ['Web Development', 'Full Stack'],
    skills: ['React', 'Node.js', 'Database Design']
  },
  {
    id: '6',
    title: 'Voice-Controlled Home Automation',
    description: 'Create a system to control home appliances using voice commands with integration for Alexa or Google Assistant.',
    category: 'Electrical Engineering',
    difficulty: 'Intermediate',
    duration: '2-3 months',
    tags: ['IoT', 'Voice Recognition', 'Smart Home'],
    skills: ['Python', 'Raspberry Pi', 'API Integration']
  },
  {
    id: '7',
    title: 'Student Collaboration Network',
    description: 'Develop a social platform specifically for students to find project partners, share resources, and collaborate on assignments.',
    category: 'Computer Science',
    difficulty: 'Advanced',
    duration: '4-5 months',
    tags: ['Social Platform', 'Web Development'],
    skills: ['React', 'Real-time Communication', 'Database']
  },
  {
    id: '8',
    title: 'Gesture-Based Gaming Controller',
    description: 'Build a controller that uses hand gestures detected by camera to control games, using computer vision techniques.',
    category: 'Computer Science',
    difficulty: 'Advanced',
    duration: '3-4 months',
    tags: ['Computer Vision', 'Gaming', 'Hardware'],
    skills: ['Python', 'OpenCV', 'Machine Learning']
  },
  {
    id: '9',
    title: 'Smart Attendance System',
    description: 'Create a facial recognition-based attendance system for classrooms that automatically marks attendance and generates reports.',
    category: 'Computer Science',
    difficulty: 'Intermediate',
    duration: '2-3 months',
    tags: ['Computer Vision', 'Face Recognition'],
    skills: ['Python', 'OpenCV', 'Database Design']
  },
  {
    id: '10',
    title: 'Renewable Energy Monitor',
    description: 'Design a system to monitor and analyze energy consumption and generation from solar panels, with visualization dashboard.',
    category: 'Electrical Engineering',
    difficulty: 'Intermediate',
    duration: '2-3 months',
    tags: ['IoT', 'Data Visualization', 'Renewable Energy'],
    skills: ['Arduino', 'Web Development', 'Data Analysis']
  },
  {
    id: '11',
    title: 'Recipe Recommendation App',
    description: 'Build an app that suggests recipes based on available ingredients using image recognition and nutritional data analysis.',
    category: 'Computer Science',
    difficulty: 'Beginner',
    duration: '1-2 months',
    tags: ['Mobile App', 'API Integration'],
    skills: ['React Native', 'REST API', 'Database']
  },
  {
    id: '12',
    title: 'Autonomous Line Following Robot',
    description: 'Create a robot that can follow a line path autonomously using sensors and microcontroller programming.',
    category: 'Robotics',
    difficulty: 'Beginner',
    duration: '1-2 months',
    tags: ['Robotics', 'Arduino', 'Sensors'],
    skills: ['C++', 'Circuit Design', 'Motor Control']
  }
];

const categories = ['All', 'Computer Science', 'Electrical Engineering', 'Robotics'];
const difficulties = ['All', 'Beginner', 'Intermediate', 'Advanced'];

export function ProjectIdeas({ searchQuery }: { searchQuery: string }) {
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [selectedDifficulty, setSelectedDifficulty] = useState('All');

  const filteredProjects = useMemo(() => {
    return projectsData.filter((project) => {
      const matchesSearch = searchQuery === '' || 
        project.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        project.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        project.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()));
      
      const matchesCategory = selectedCategory === 'All' || project.category === selectedCategory;
      const matchesDifficulty = selectedDifficulty === 'All' || project.difficulty === selectedDifficulty;

      return matchesSearch && matchesCategory && matchesDifficulty;
    });
  }, [searchQuery, selectedCategory, selectedDifficulty]);

  return (
    <div>
      {/* Filters */}
      <div className="mb-6 flex flex-wrap gap-4">
        <div>
          <label className="text-sm font-medium text-gray-700 mb-2 block">Category</label>
          <div className="flex flex-wrap gap-2">
            {categories.map((category) => (
              <Button
                key={category}
                variant={selectedCategory === category ? 'default' : 'outline'}
                size="sm"
                onClick={() => setSelectedCategory(category)}
              >
                {category}
              </Button>
            ))}
          </div>
        </div>

        <div>
          <label className="text-sm font-medium text-gray-700 mb-2 block">Difficulty</label>
          <div className="flex flex-wrap gap-2">
            {difficulties.map((difficulty) => (
              <Button
                key={difficulty}
                variant={selectedDifficulty === difficulty ? 'default' : 'outline'}
                size="sm"
                onClick={() => setSelectedDifficulty(difficulty)}
              >
                {difficulty}
              </Button>
            ))}
          </div>
        </div>
      </div>

      {/* Results Count */}
      <div className="mb-4 text-sm text-gray-600">
        Found {filteredProjects.length} project{filteredProjects.length !== 1 ? 's' : ''}
      </div>

      {/* Project Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredProjects.map((project) => (
          <Card key={project.id} className="flex flex-col hover:shadow-lg transition-shadow">
            <CardHeader>
              <div className="flex items-start justify-between mb-2">
                <Badge variant="secondary">{project.category}</Badge>
                <Badge 
                  variant={
                    project.difficulty === 'Beginner' ? 'default' : 
                    project.difficulty === 'Intermediate' ? 'secondary' : 
                    'destructive'
                  }
                >
                  {project.difficulty}
                </Badge>
              </div>
              <CardTitle className="text-xl">{project.title}</CardTitle>
              <CardDescription className="line-clamp-3">{project.description}</CardDescription>
            </CardHeader>

            <CardContent className="flex-1">
              <div className="space-y-3">
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <Clock className="h-4 w-4" />
                  <span>{project.duration}</span>
                </div>

                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <Code2 className="h-4 w-4 text-gray-600" />
                    <span className="text-sm font-medium">Skills Required:</span>
                  </div>
                  <div className="flex flex-wrap gap-1">
                    {project.skills.map((skill, idx) => (
                      <Badge key={idx} variant="outline" className="text-xs">
                        {skill}
                      </Badge>
                    ))}
                  </div>
                </div>

                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <TrendingUp className="h-4 w-4 text-gray-600" />
                    <span className="text-sm font-medium">Tags:</span>
                  </div>
                  <div className="flex flex-wrap gap-1">
                    {project.tags.map((tag, idx) => (
                      <Badge key={idx} variant="outline" className="text-xs bg-blue-50">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                </div>
              </div>
            </CardContent>

            <CardFooter className="flex gap-2">
              <Button className="flex-1" variant="default">
                <GraduationCap className="h-4 w-4 mr-2" />
                Start Project
              </Button>
              <Button variant="outline" size="icon">
                <BookmarkPlus className="h-4 w-4" />
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>

      {filteredProjects.length === 0 && (
        <div className="text-center py-12">
          <p className="text-gray-500 text-lg">No projects found matching your criteria.</p>
          <p className="text-gray-400 mt-2">Try adjusting your filters or search query.</p>
        </div>
      )}
    </div>
  );
}
