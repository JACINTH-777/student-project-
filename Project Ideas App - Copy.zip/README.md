
  # Project Ideas App

  This is a code bundle for Project Ideas App. The original project is available at https://www.figma.com/design/HRYpju2qZWdNdnbN7CR3Wz/Project-Ideas-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  